import { Link } from 'react-router-dom'
import { useState } from 'react'

const caseStudies = [
    { title: 'Comprehensive SEO Audit', tag: 'SEO', img: 'case-img9.png', category: 'seo' },
    { title: 'Keyword Research & Analysis', tag: 'Web', img: 'case-img10.png', category: 'web' },
    { title: 'One Page Optimization', tag: 'PPC', img: 'case-img11.png', category: 'ppc' },
    { title: 'Online Media Management', tag: 'Branding Marketing', img: 'case-img12.png', category: 'branding' },
    { title: 'Online Management', tag: 'Web', img: 'case-img13.png', category: 'web' },
    { title: 'Online Media Management', tag: 'Branding, Marketing', img: 'case-img14.png', category: 'branding' },
    { title: 'Domain Migration', tag: 'Branding, SEO', img: 'case-img15.png', category: 'seo' },
]

const categories = [
    { id: 'all', label: 'All' },
    { id: 'branding', label: 'Branding' },
    { id: 'digital-pr', label: 'Digital PR' },
    { id: 'ppc', label: 'PPC' },
    { id: 'marketing', label: 'Marketing' },
    { id: 'seo', label: 'SEO' },
    { id: 'web', label: 'Web' },
]

export default function CaseStudy() {
    const [activeTab, setActiveTab] = useState('all')

    const filteredCases = activeTab === 'all'
        ? caseStudies
        : caseStudies.filter(c => c.category === activeTab)

    return (
        <>
            {/* PAGE HEADER */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Social Media Marketing</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> Case <i className="fa-solid fa-angle-right"></i> <span>Social Media Marketing</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CASE AREA */}
            <div className="case-inner-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-4 m-auto">
                            <div className="case-header text-center heading2">
                                <h5>Case</h5>
                                <h2>Our Case Studies</h2>
                            </div>
                            <div className="space50 d-lg-block d-none"></div>
                            <div className="space30 d-lg-none d-block"></div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-lg-7 m-auto">
                            <div className="tabs-area text-center">
                                <ul className="nav nav-pills">
                                    {categories.map(cat => (
                                        <li className="nav-item" key={cat.id}>
                                            <button
                                                className={`nav-link ${activeTab === cat.id ? 'active' : ''}`}
                                                onClick={() => setActiveTab(cat.id)}
                                            >
                                                {cat.label}
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                        <div className="col-lg-12">
                            <div className="tabs-content-area">
                                <div className="tab-content">
                                    <div className="tabs-contents">
                                        <div className="row align-items-center">
                                            {filteredCases.map((c, i) => (
                                                <div className="col-lg-4" key={i}>
                                                    <div className="case-inner-box">
                                                        <div className="img1 image-anime">
                                                            <img src={`/assets/img/all-images/${c.img}`} alt="" />
                                                        </div>
                                                        <div className="content-area">
                                                            <div className="link-area">
                                                                <Link to="/case/1" className="tags">#{c.tag}</Link>
                                                                <Link to="/case/1" className="head">{c.title}</Link>
                                                            </div>
                                                            <div className="arrow">
                                                                <Link to="/case/1"><i className="fa-solid fa-arrow-right"></i></Link>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="space30"></div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CTA SECTION */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
