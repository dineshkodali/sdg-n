import { Link } from 'react-router-dom'

const team = [
    { name: 'John Doe', role: 'CEO & Founder', img: 'team-img1.png' },
    { name: 'Jane Smith', role: 'Digital Marketing Officer', img: 'team-img2.png' },
    { name: 'Sarah Thompson', role: 'Web Designer', img: 'team-img3.png' },
    { name: 'David Garcia', role: 'Content Writer', img: 'team-img4.png' },
]

export default function Team() {
    return (
        <>
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Team</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>Team</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="team-inner-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="team2-header-area text-center heading2">
                                <h5>Team</h5>
                                <h2>Meet With Our Expert Team</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {team.map((m, i) => (
                            <div className="col-lg-3 col-md-6" key={i}>
                                <div className={`team-boxarea${i === team.length - 1 ? ' m-0' : ''}`}>
                                    <div className="img1">
                                        <img src={`/assets/img/all-images/${m.img}`} alt="" />
                                    </div>
                                    <ul>
                                        <li><a href="#"><img src="/assets/img/icons/facebook.svg" alt="" /></a></li>
                                        <li><a href="#"><img src="/assets/img/icons/instagram.svg" alt="" /></a></li>
                                        <li><a href="#"><img src="/assets/img/icons/linkedin.svg" alt="" /></a></li>
                                        <li><a href="#" className="m-0"><img src="/assets/img/icons/youtube.svg" alt="" /></a></li>
                                    </ul>
                                    <div className="content">
                                        <a href="#">{m.name}</a>
                                        <p>{m.role}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    )
}
