import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react'

const faqs = [
    { id: 'flush-collapseOne', q: 'How does SEO differ from PPC?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
    { id: 'flush-collapseTwo', q: 'What is local SEO and who needs it?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
    { id: 'flush-collapseThree', q: 'How does voice search impact SEO?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
    { id: 'flush-collapseFour', q: 'What is SEO and why is it important?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
    { id: 'flush-collapseFive', q: 'What are the key components of a successful SEO strategy?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
    { id: 'flush-collapseSix', q: 'How can I measure the success of my digital marketing efforts?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
    { id: 'flush-collapseSeven', q: 'What are some common SEO mistakes to avoid?', a: 'Common mistakes include keyword stuffing, neglecting mobile optimization, ignoring technical SEO, using duplicate content, not optimizing for local search, and failing to monitor and analyze SEO performance.' },
]

export default function Faq() {
    const [openIndex, setOpenIndex] = useState(0);

    useEffect(() => {
        if (window.jQuery) {
            const $ = window.jQuery;
            $('.testimonials-slider-area').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                dots: true,
                items: 1,
                autoplay: true,
                smartSpeed: 3000,
                autoplayTimeout: 4000,
                responsive: {
                    0: { items: 1 },
                    600: { items: 1 },
                    1000: { items: 1 }
                }
            });
        }
    }, []);

    return (
        <>
            {/* HERO AREA STARTS */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Frequently Asked Question</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>FAQ'S</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* HERO AREA ENDS */}

            {/* CHOOSE AREA STARTS */}
            <div className="choose-section-area sp8" style={{ background: 'none' }}>
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-10 m-auto">
                            <div className="accordian-tabs-area" style={{ padding: '0' }}>
                                <div className="accordion accordion-flush" id="accordionFlushExample">
                                    {faqs.map((faq, index) => (
                                        <div key={faq.id}>
                                            <div className="accordion-item">
                                                <h2 className="accordion-header">
                                                    <button
                                                        className={`accordion-button ${openIndex === index ? '' : 'collapsed'}`}
                                                        type="button"
                                                        onClick={() => setOpenIndex(index)}
                                                    >
                                                        {faq.q}
                                                    </button>
                                                </h2>
                                                <div className={`accordion-collapse collapse ${openIndex === index ? 'show' : ''}`} data-bs-parent="#accordionFlushExample">
                                                    <div className="accordion-body body2">
                                                        {faq.a}
                                                    </div>
                                                </div>
                                            </div>
                                            {index < faqs.length - 1 && <div className="space24"></div>}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* CHOOSE AREA ENDS */}

            {/* CONTACT AREA STARTS */}
            <div className="contact-inner-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="heading2 text-center">
                                <h5>Contact Us Now</h5>
                                <h2>Not Found Your Answer? Just Ask Us!</h2>
                            </div>
                            <div className="space60 d-lg-block d-none"></div>
                            <div className="space30 d-lg-none d-md-block"></div>
                        </div>
                        <div className="col-lg-10 m-auto">
                            <div className="contact-form-area">
                                <div className="row">
                                    <div className="col-lg-6">
                                        <div className="input-area">
                                            <input type="text" placeholder="First Name" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="input-area">
                                            <input type="text" placeholder="Last Name" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="input-area">
                                            <input type="email" placeholder="Email" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="input-area">
                                            <input type="number" placeholder="Phone" />
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="input-area">
                                            <input type="text" placeholder="Subject" />
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="input-area">
                                            <textarea placeholder="Message"></textarea>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="space24"></div>
                                        <div className="input-area">
                                            <button type="submit" className="header-btn1">Submit <span><i className="fa-solid fa-arrow-right"></i></span></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* CONTACT AREA ENDS */}

            {/* TESTIMONIAL AREA STARTS */}
            <div className="testimonial1-section-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="testimonial-header heading2 text-center">
                                <img src="/assets/img/elements/star7.png" alt="" className="star2 keyframe5" />
                                <img src="/assets/img/elements/star7.png" alt="" className="star3 keyframe5" />
                                <h5>Testimonials</h5>
                                <h2>What Our Client Say <br className="d-md-block d-none" /> On Google Reviews</h2>
                                <p>Don't just take our word for it. Hear what our satisfied clients <br className="d-md-block d-none" /> have to say about their experience partnering with SDG Solutions</p>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="testimonials-slider-area owl-carousel">
                                {[1, 2, 2].map((imgNum, idx) => (
                                    <div key={idx} className="testimonial-boxarea">
                                        <div className="row">
                                            <div className="col-lg-5">
                                                <div className="pera">
                                                    <p>"Working with SDG Solutions has been a game-changer for our business. Their expertise in SEO and digital marketing has helped us achieve remarkable results and significantly increase our online visibility.</p>
                                                    <div className="space100"></div>
                                                    <div className="space30"></div>
                                                    <div className="list-area">
                                                        <div className="list">
                                                            <ul>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                            </ul>
                                                            <Link to="/team">John Doe</Link>
                                                        </div>
                                                        <img src="/assets/img/icons/google.svg" alt="" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-lg-7">
                                                <div className="images">
                                                    <img src={`/assets/img/all-images/testimonial-img${imgNum}.png`} alt="" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* TESTIMONIAL AREA ENDS */}

            {/* CTA AREA STARTS */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* CTA AREA ENDS */}
        </>
    )
}
