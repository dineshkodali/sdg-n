import { Link } from 'react-router-dom'

const blogs = [
    { img: 'blog-img1.png', title: '10 Essential SEO Tips to Boost Your Website\'s Ranking', excerpt: 'Are you looking to improve your website\'s visibility and attract more organic traffic?' },
    { img: 'blog-img2.png', title: 'The Power of PPC Advertising: How to Maximize Your ROI', excerpt: 'Unlock the full potential of your digital marketing strategy with the power of PPC.' },
    { img: 'blog-img3.png', title: 'The Importance of Responsive Web Design in the Mobile Age', excerpt: 'Where mobile devices dominate internet usage, responsive web design more crucial.' },
    { img: 'blog-img15.png', title: 'The Power of Content Marketing: How to Drive Engagement...', excerpt: 'Are you looking to improve your website\'s visibility and attract more organic traffic?' },
    { img: 'blog-img16.png', title: 'The Importance of SEO in Digital Marketing:A Comprehensive Guide', excerpt: 'Unlock the full potential of your digital marketing strategy with the power of PPC.' },
    { img: 'blog-img3.png', title: 'The Power of Social Media Marketing: How to Build Your...', excerpt: 'Where mobile devices dominate internet usage, responsive web design more crucial.' },
]

export default function Blog() {
    return (
        <>
            {/* PAGE HEADER */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Blog</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>Blog</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* FEATURED BLOG AREA */}
            <div className="blog-top-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="blog-top-boxarea">
                                <div className="row align-items-center">
                                    <div className="col-lg-5">
                                        <div className="content-area heading2">
                                            <div className="tags-area">
                                                <ul>
                                                    <li><a href="#"><img src="/assets/img/icons/contact1.svg" alt="" />Ben Stokes</a></li>
                                                    <li><a href="#"><img src="/assets/img/icons/calender1.svg" alt="" />16 August 2023</a></li>
                                                </ul>
                                            </div>
                                            <h2>The Power of PPC Advertising: How to Maximize Your ROI</h2>
                                            <div className="space16"></div>
                                            <div className="btn-area">
                                                <Link to="/blog/1" className="header-btn1">Read Full Story <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-2"></div>
                                    <div className="col-lg-5">
                                        <div className="images image-anime">
                                            <img src="/assets/img/all-images/blog-img19.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* BLOG GRID */}
            <div className="blog1-scetion-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        {blogs.map((b, i) => (
                            <div className="col-lg-4 col-md-6" key={i} data-aos="zoom-in" data-aos-duration={800 + (i % 3) * 200}>
                                <div className="blog-author-boxarea">
                                    <div className="img1">
                                        <img src={`/assets/img/all-images/${b.img}`} alt="" />
                                    </div>
                                    <div className="content-area">
                                        <div className="tags-area">
                                            <ul>
                                                <li><a href="#"><img src="/assets/img/icons/contact1.svg" alt="" />Ben Stokes</a></li>
                                                <li><a href="#"><img src="/assets/img/icons/calender1.svg" alt="" />16 August 2023</a></li>
                                            </ul>
                                        </div>
                                        <Link to={`/blog/${i + 1}`}>{b.title}</Link>
                                        <p>{b.excerpt}</p>
                                        <Link to={`/blog/${i + 1}`} className="readmore">Read More <i className="fa-solid fa-arrow-right"></i></Link>
                                    </div>
                                </div>
                                <div className="space30"></div>
                            </div>
                        ))}

                        <div className="col-lg-12">
                            <div className="pagination-area">
                                <nav aria-label="Page navigation example">
                                    <ul className="pagination justify-content-center">
                                        <li className="page-item">
                                            <a className="page-link" href="#"><i className="fa-solid fa-angle-left"></i></a>
                                        </li>
                                        <li className="page-item"><a className="page-link active" href="#">1</a></li>
                                        <li className="page-item"><a className="page-link" href="#">2</a></li>
                                        <li className="page-item"><a className="page-link" href="#">3</a></li>
                                        <li className="page-item">
                                            <a className="page-link" href="#"><i className="fa-solid fa-angle-right"></i></a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CTA AREA */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
