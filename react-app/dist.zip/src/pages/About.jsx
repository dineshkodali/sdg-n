import { Link } from 'react-router-dom'
import { useEffect } from 'react'

export default function About() {
    useEffect(() => {
        if (window.jQuery) {
            const $ = window.jQuery;

            // Brands Slider
            $('.slider-images-area').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayTimeout: 3000,
                responsive: {
                    0: { items: 2 },
                    600: { items: 3 },
                    1000: { items: 5 }
                }
            });

            // Testimonials Slider
            $('.testimonials-slider-area').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                dots: true,
                items: 1,
                autoplay: true,
                smartSpeed: 3000,
                autoplayTimeout: 4000,
                responsive: {
                    0: { items: 1 },
                    600: { items: 1 },
                    1000: { items: 1 }
                }
            });
        }
    }, []);

    return (
        <>
            {/* HERO AREA STARTS */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>About</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>About</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* HERO AREA ENDS */}

            {/* ABOUT AREA STARTS */}
            <div className="about1-section-area sp6 bg-white">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-4">
                            <div className="about-images">
                                <figure className="image-anime">
                                    <img src="/assets/img/all-images/about-img1.png" alt="" />
                                </figure>
                                <img src="/assets/img/elements/star1.png" alt="" className="star1 keyframe5" />
                            </div>
                        </div>
                        <div className="col-lg-5">
                            <div className="about-content-area heading2">
                                <div className="arrow-circle">
                                    <Link to="/about">
                                        <img src="/assets/img/elements/elements4.png" alt="" className="elements4 keyframe5" />
                                        <img src="/assets/img/icons/arrow.svg" alt="" className="arrow" />
                                    </Link>
                                </div>
                                <h2>Comprehensive SEO & Digital Marketing Solutions.</h2>
                                <p>Welcome to SDG Solutions your trusted partner for comprehensive SEO and digital marketing solutions. With our proven expertise and innovative strategies the digital landscape.</p>
                                <div className="btn-area">
                                    <Link to="/about" className="header-btn1">Learn More<span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3">
                            <div className="about-auhtor-images">
                                <img src="/assets/img/elements/elements5.png" alt="" className="elements5 keyframe5" />
                                <figure className="image-anime">
                                    <img src="/assets/img/all-images/about-img2.png" alt="" />
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* ABOUT AREA ENDS */}

            <div className="space60"></div>

            {/* TESTIMONIAL(BRAND) AREA STARTS */}
            <div className="slider-section-area slider-inner sp5">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-2">
                            <div className="sldier-head">
                                <p>Trusted by <br className="d-lg-block d-none" /> Top Companies</p>
                            </div>
                        </div>
                        <div className="col-lg-10">
                            <div className="slider-images-area owl-carousel">
                                {[1, 2, 3, 4, 5].map(n => (
                                    <div className="img1" key={n}>
                                        <img src={`/assets/img/elements/brand-img${n}.png`} alt="" />
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* TESTIMONIAL(BRAND) AREA ENDS */}

            {/* WORK AREA STARTS */}
            <div className="works-inner-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="works-header-area heading2">
                                <h5>Why Choose Us</h5>
                                <h2>Experience the Advantage Why We're the Right Choice</h2>
                                <p>At SDG Solutions we understand that you have many options when it comes to digital marketing services. Here are a few reasons</p>
                                <div className="space32"></div>
                                {[
                                    { icon: 'works-icons7.svg', title: 'Proven Result', desc: 'We have a track record of delivering tangible results for our clients. From increasing website traffic and improving search.' },
                                    { icon: 'works-icons8.svg', title: 'Customized Solutions', desc: 'We believe that one size does not fit all when it comes to digital marketing. That\'s why we take the time to understand.' },
                                    { icon: 'works-icons9.svg', title: 'Dedicated Support', desc: 'Your success is our top priority. That\'s why provide dedicated support and guidance every step of the way to running seo.' }
                                ].map((item, idx) => (
                                    <div key={idx} className="works-content-box" style={{ marginBottom: idx < 2 ? '20px' : '0' }}>
                                        <div className="icons">
                                            <img src={`/assets/img/icons/${item.icon}`} alt="" />
                                        </div>
                                        <div className="content">
                                            <Link to="/case">{item.title}</Link>
                                            <p>{item.desc}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="about-all-images-area">
                                <img src="/assets/img/elements/elements14.png" alt="" className="elements12 keyframe5" />
                                <img src="/assets/img/elements/elements15.png" alt="" className="elements13 keyframe5" />
                                <div className="row">
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img1 image-anime">
                                            <div className="space100"></div>
                                            <img src="/assets/img/all-images/about-img6.png" alt="" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img2 image-anime">
                                            <img src="/assets/img/all-images/about-img5.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* WORK AREA ENDS */}

            {/* SERVICE AREA STARTS (OUR VALUE) */}
            <div className="service2-section-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="service2-header heading2 text-center">
                                <img src="/assets/img/elements/star7.png" alt="" className="star2 keyframe5" />
                                <img src="/assets/img/elements/star7.png" alt="" className="star3 keyframe5" />
                                <h5>Our Value</h5>
                                <h2>Tailored Solutions, Proven Results, <br className="d-md-block d-none" /> And Exceptional Service</h2>
                                <p>We pride ourselves on delivering a value proposition that goes beyond expectations. Our <br className="d-md-block d-none" /> approach is centered on understanding your business inside</p>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-7">
                            <div className="images-content-area active">
                                <div className="img1">
                                    <img src="/assets/img/all-images/service-img1.png" alt="" />
                                </div>
                                <div className="content-area">
                                    <h5>Our Value</h5>
                                    <Link to="/services" className="text">Explore Our Unique Value Proposition & How We Drive Business Growth</Link>
                                    <p>we're committed to delivering exceptional value to our clients. We understand that every business is unique, personalized approach to every project we undertake.</p>
                                    <div className="btn-area">
                                        <Link to="/services" className="header-btn1">Learn More <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                    </div>
                                </div>
                                <div className="arrow-area">
                                    <Link to="/services"><i className="fa-solid fa-arrow-right"></i></Link>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-5">
                            <div className="service-all-boxes">
                                <div className="row">
                                    <div className="col-lg-12 col-md-6">
                                        <div className="service2-auhtor-boxarea">
                                            <div className="arrow">
                                                <Link to="/services"><i className="fa-solid fa-arrow-right"></i></Link>
                                            </div>
                                            <div className="content-area">
                                                <h5>Our Mission</h5>
                                                <Link to="/services">We strive to be more than just a service provider; we aim to be trusted SDG Solutions </Link>
                                                <p>By staying true to our mission and values, we are committed to helping businesses of all sizes achieve their goals, realize their potential shape.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-lg-12 col-md-6">
                                        <div className="service2-auhtor2-boxarea">
                                            <div className="arrow">
                                                <Link to="/services"><i className="fa-solid fa-arrow-right"></i></Link>
                                            </div>
                                            <div className="content-area">
                                                <h5>Our Vision</h5>
                                                <Link to="/services">We aspire to create a world where every business owner feels empowered</Link>
                                                <p>By staying true to our vision and values, we are committed to driving positive change and shaping a brighter future for businesses and communities.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* SERVICE AREA ENDS */}

            {/* HISTORY AREA STARTS */}
            <div className="history-inner-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="history-header-area text-center heading2">
                                <img src="/assets/img/elements/star7.png" alt="" className="star2 keyframe5" />
                                <img src="/assets/img/elements/star7.png" alt="" className="star3 keyframe5" />
                                <h5>Our History</h5>
                                <h2>Our Journey: Charting the <br className="d-lg-block d-none" /> Evolution of SDG Solutions</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="about-all-images-area">
                                <img src="/assets/img/elements/elements14.png" alt="" className="elements12 keyframe5" />
                                <img src="/assets/img/elements/elements15.png" alt="" className="elements13 keyframe5" />
                                <div className="row">
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img1 image-anime">
                                            <div className="space100"></div>
                                            <img src="/assets/img/all-images/history-img1.png" alt="" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img2 image-anime">
                                            <img src="/assets/img/all-images/history-img2.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-6">
                            <div className="history-content-area">
                                <div className="row">
                                    {[
                                        { year: '2015', title: 'Inception and Founding', desc: 'SDG Solutions was founded with a vision to revolutionize the digital marketing industry and provide innovation.' },
                                        { year: '2016', title: 'Expansion and Growth', desc: 'The team expanded to include additional members with diverse skill sets and expertise allowing us.' },
                                        { year: '2017', title: 'Recognition and Awards', desc: 'We were honored to recognized as a leader in the digital marketing space and received accolades customer.' },
                                        { year: '2018', title: 'Launch of New Services', desc: 'Building on our success, SDG Solutions expanded our service offerings to better meet the evolving needs.' },
                                        { year: '2019', title: 'Strategic Partnerships', desc: 'SDG Solutions formed strategic partnerships and collaborations with industry leaders and technology providers.' },
                                        { year: '2020', title: 'Continued Growth Success', desc: '2020 continued to experience steady growth and success, despite ongoing challenges in external environment.' }
                                    ].map((box, idx) => (
                                        <div key={idx} className="col-lg-6 col-md-6">
                                            <div className="history-box-content">
                                                <h5>{box.year}</h5>
                                                <Link to="/services">{box.title}</Link>
                                                <p>{box.desc}</p>
                                                <Link to="/services" className="readmore">Read More <i className="fa-solid fa-arrow-right"></i></Link>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* HISTORY AREA ENDS */}

            {/* SKILLS AREA STARTS */}
            <div className="skills-section-area sp2">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 m-auto">
                            <div className="skills-header text-center heading2">
                                <h5>Skills</h5>
                                <h2>Our Skills</h2>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-10 m-auto">
                        <div className="circle-progress-area">
                            <div className="row">
                                {[
                                    { percent: 82, label: 'S M M' },
                                    { percent: 49, label: 'P P C', className: 'two' },
                                    { percent: 99, label: 'SEO', className: 'three' },
                                    { percent: 95, label: 'Digital Marketing', className: 'four' }
                                ].map((skill, idx) => (
                                    <div key={idx} className="col-lg-3 col-md-6">
                                        <div className="progresbar">
                                            <div className="progressbar">
                                                <div className={`circle ${skill.className || ''}`} data-percent={skill.percent}>
                                                    <canvas width="180" height="180"></canvas>
                                                    <div>{skill.percent}%</div>
                                                </div>
                                            </div>
                                            <p>{skill.label}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* SKILLS AREA ENDS */}

            {/* TEAM AREA STARTS */}
            <div className="team-inner-section-area sp2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="team2-header-area text-center heading2">
                                <h5>Our Team</h5>
                                <h2>Meet With Our Expert Team</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { name: 'John Doe', role: 'CEO & Founder', img: 'team-img1.png' },
                            { name: 'Jane Smith', role: 'Digital Marketing Officer', img: 'team-img2.png' },
                            { name: 'Sarah Thompson', role: 'Web Designer', img: 'team-img3.png' },
                            { name: 'David Garcia', role: 'Content Writer', img: 'team-img4.png' }
                        ].map((member, idx) => (
                            <div key={idx} className="col-lg-3 col-md-6">
                                <div className={`team-boxarea ${idx === 3 ? 'm-0' : ''}`}>
                                    <div className="img1">
                                        <img src={`/assets/img/all-images/${member.img}`} alt="" />
                                    </div>
                                    <ul>
                                        <li><Link to="#"><img src="/assets/img/icons/facebook.svg" alt="" /></Link></li>
                                        <li><Link to="#"><img src="/assets/img/icons/instagram.svg" alt="" /></Link></li>
                                        <li><Link to="#"><img src="/assets/img/icons/linkedin.svg" alt="" /></Link></li>
                                        <li><Link to="#" className="m-0"><img src="/assets/img/icons/youtube.svg" alt="" /></Link></li>
                                    </ul>
                                    <div className="content">
                                        <Link to="/team">{member.name}</Link>
                                        <p>{member.role}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            {/* TEAM AREA ENDS */}

            {/* TESTIMONIAL AREA STARTS */}
            <div className="testimonial1-section-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="testimonial-header heading2 text-center">
                                <img src="/assets/img/elements/star7.png" alt="" className="star2 keyframe5" />
                                <img src="/assets/img/elements/star7.png" alt="" className="star3 keyframe5" />
                                <h5>Testimonials</h5>
                                <h2>What Our Client Say <br className="d-md-block d-none" /> On Google Reviews</h2>
                                <p>Don't just take our word for it. Hear what our satisfied clients <br className="d-md-block d-none" /> have to say about their experience partnering with SDG Solutions</p>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="testimonials-slider-area owl-carousel">
                                {[1, 2, 2].map((imgNum, idx) => (
                                    <div key={idx} className="testimonial-boxarea">
                                        <div className="row">
                                            <div className="col-lg-5">
                                                <div className="pera">
                                                    <p>"Working with SDG Solutions has been a game-changer for our business. Their expertise in SEO and digital marketing has helped us achieve remarkable results and significantly increase our online visibility.</p>
                                                    <div className="space100"></div>
                                                    <div className="space30"></div>
                                                    <div className="list-area">
                                                        <div className="list">
                                                            <ul>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                                <li><i className="fa-solid fa-star"></i></li>
                                                            </ul>
                                                            <Link to="/team">John Doe</Link>
                                                        </div>
                                                        <img src="/assets/img/icons/google.svg" alt="" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-lg-7">
                                                <div className="images">
                                                    <img src={`/assets/img/all-images/testimonial-img${imgNum}.png`} alt="" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* TESTIMONIAL AREA ENDS */}

            {/* CTA AREA STARTS */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* CTA AREA ENDS */}
        </>
    )
}
