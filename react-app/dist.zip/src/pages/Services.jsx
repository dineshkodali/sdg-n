import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'

const services = [
    { icon: 'service-icon1.svg', title: 'Search Engine Optimization ( SEO)', desc: 'Enhance your online visibility & drive organic traffic with our advanced SEO techniques. We optimize your website to rank higher.' },
    { icon: 'service-icon2.svg', title: 'Pay-Per-Click (PPC) Advertising', desc: 'Reach your audience instantly and drive qualified leads with targeted PPC campaigns. Our experts craft compelling ad copy and optimize.' },
    { icon: 'service-icon3.svg', title: 'Social Media Marketing', desc: 'Build a strong brand presence and engage with your audience on social media platforms. We create strategic social media campaigns to boost brand.' },
    { icon: 'service-icon4.svg', title: 'Website Design and Development', desc: 'Make a lasting impression with a professionally designed and user-friendly website. Our web design and development services ensure website.' },
]

export default function Services() {
    const [activeCaseIndex, setActiveCaseIndex] = useState(0);

    useEffect(() => {
        // Re-initialize Owl Carousel or any other plugins if needed
        if (window.jQuery) {
            const $ = window.jQuery;
            $('.slider-images-area').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayTimeout: 3000,
                responsive: {
                    0: { items: 2 },
                    600: { items: 3 },
                    1000: { items: 5 }
                }
            });
        }
    }, []);

    return (
        <>
            {/* HERO AREA STARTS */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Social Media Marketing</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> Services <i className="fa-solid fa-angle-right"></i> <span>Social Media Marketing</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* INTRO AREA STARTS */}
            <div className="service-inner2-section-area sp8">
                <img src="/assets/img/elements/instagram1.png" alt="" className="instagram1" />
                <img src="/assets/img/elements/linkedin1.png" alt="" className="linkedin1" />
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="service-images">
                                <img src="/assets/img/elements/facebook1.png" alt="" className="facebook1" />
                                <img src="/assets/img/elements/twitter1.png" alt="" className="twitter1" />
                                <img src="/assets/img/all-images/service-img11.png" alt="" />
                                <img src="/assets/img/bg/inner-bg1.png" alt="" className="inner-bg1" />
                            </div>
                        </div>
                        <div className="col-lg-5">
                            <div className="service-content heading2">
                                <h5>Social Media Marketing</h5>
                                <h2>Social Media Marketing</h2>
                                <p>Welcome to SDG Solutions’ Social Media Marketing Services. Our team specializes in crafting and executing social media strategies that elevate your brand, engage your audience, and drive measurable results. Harness the power of social media to grow your business and connect with customers on a deeper level.</p>
                                <div className="space32"></div>
                                <div className="btn-area1">
                                    <Link to="/contact" className="header-btn1">View Our Services <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* TESTIMONIAL AREA STARTS (BRANDS) */}
            <div className="slider-section-area slider-inner sp5">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-2">
                            <div className="sldier-head">
                                <p>Trusted by <br className="d-lg-block d-none" /> Top Companies</p>
                            </div>
                        </div>
                        <div className="col-lg-10">
                            <div className="slider-images-area owl-carousel">
                                <div className="img1"><img src="/assets/img/elements/brand-img1.png" alt="" /></div>
                                <div className="img1"><img src="/assets/img/elements/brand-img2.png" alt="" /></div>
                                <div className="img1"><img src="/assets/img/elements/brand-img3.png" alt="" /></div>
                                <div className="img1"><img src="/assets/img/elements/brand-img4.png" alt="" /></div>
                                <div className="img1"><img src="/assets/img/elements/brand-img5.png" alt="" /></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CASE STUDY AREA STARTS */}
            <div className="case1-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="case-header-area heading2 text-center">
                                <h5>Case Study</h5>
                                <h2 className="text-anime-style-3">SDG Solutions Case Study</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="cs_case_study_1_list">
                                {[
                                    { title: 'Website Design & Development', img: 'case-img1.png', link: '/case/1', desc: 'We understand the critical role that a well-designed and user-friendly website plays in shaping your online presence driving.' },
                                    { title: 'SEO', img: 'case-img2.png', link: '/case/2', desc: 'We understand the critical role that a well-designed and user-friendly website plays in shaping your online presence driving.' },
                                    { title: 'PPC Advertising', img: 'case-img3.png', link: '/case/3', desc: 'We understand the critical role that a well-designed and user-friendly website plays in shaping your online presence driving.' },
                                    { title: 'Social Media Marketing', img: 'case-img4.png', link: '/case/4', desc: 'We understand the critical role that a well-designed and user-friendly website plays in shaping your online presence driving.' },
                                ].map((item, index) => (
                                    <div
                                        key={index}
                                        className={`cs_case_study cs_style_1 cs_hover_active${activeCaseIndex === index ? ' active' : ''}`}
                                        onMouseEnter={() => setActiveCaseIndex(index)}
                                    >
                                        <Link to={item.link} className="cs_case_study_thumb cs_bg_filed" style={{ backgroundImage: `url(/assets/img/all-images/${item.img})` }}></Link>
                                        <div className="content-area1"><Link to={item.link}>{item.title}</Link></div>
                                        <div className="content-area">
                                            <Link to={item.link}>{item.title}</Link>
                                            <p>{item.desc}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* SERVICE AREA STARTS */}
            <div className="service1-section-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="service-header-area heading2 text-center">
                                <h5>Our Service</h5>
                                <h2>Social Media Service</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="service-all-boxes-area">
                                {services.map((s, i) => (
                                    <div className={`service-boxarea${i > 0 ? ` box${i + 1}` : ''}`} key={i}>
                                        <Link to="/contact">{s.title}</Link>
                                        <div className="space40"></div>
                                        <img src={`/assets/img/icons/${s.icon}`} alt="" />
                                        <div className="space40"></div>
                                        <p>{s.desc}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="col-lg-12 m-auto">
                            <div className="space50"></div>
                            <div className="btn-area1 text-center">
                                <Link to="/contact" className="header-btn1">View More Services <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CHOOSE AREA STARTS */}
            <div className="choose-section-area sp1">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="choose-header-area text-center heading2">
                                <h5>Why Choose Us</h5>
                                <h2>Why Choose SDG Solutions For PPC?</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="accordian-tabs-area">
                                <div className="accordion accordion-flush" id="accordionFlushExample">
                                    <div className="accordion-item">
                                        <h2 className="accordion-header">
                                            <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne">
                                                1. Customized Strategies
                                            </button>
                                        </h2>
                                        <div id="flush-collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionFlushExample">
                                            <div className="accordion-body">We believe in transparency and provide regular updates and detailed reports on your campaign's progress.</div>
                                            <div className="space10"></div>
                                            <div className="accordion-body body2">Ready to boost your online presence and drive more organic traffic to your website.</div>
                                        </div>
                                    </div>
                                    <div className="space24"></div>
                                    <div className="accordion-item">
                                        <h2 className="accordion-header">
                                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo">
                                                2.Transparent Reporting
                                            </button>
                                        </h2>
                                        <div id="flush-collapseTwo" className="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                                            <div className="accordion-body">We believe in transparency and provide regular updates and detailed reports on your campaign's progress.</div>
                                            <div className="space10"></div>
                                            <div className="accordion-body body2">Ready to boost your online presence and drive more organic traffic to your website.</div>
                                        </div>
                                    </div>
                                    <div className="space24"></div>
                                    <div className="accordion-item">
                                        <h2 className="accordion-header">
                                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree">
                                                3.Proven Results
                                            </button>
                                        </h2>
                                        <div id="flush-collapseThree" className="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                                            <div className="accordion-body">We believe in transparency and provide regular updates and detailed reports on your campaign's progress.</div>
                                            <div className="space10"></div>
                                            <div className="accordion-body body2">Ready to boost your online presence and drive more organic traffic to your website.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="about-all-images-area">
                                <img src="/assets/img/elements/elements14.png" alt="" className="elements12 keyframe5" />
                                <img src="/assets/img/elements/elements15.png" alt="" className="elements13 keyframe5" />
                                <div className="row">
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img1">
                                            <div className="space100"></div>
                                            <img src="/assets/img/all-images/service-img5.png" alt="" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img2">
                                            <img src="/assets/img/all-images/service-img9.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* TEAM AREA STARTS */}
            <div className="team-inner-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="team2-header-area text-center heading2">
                                <h5>Team</h5>
                                <h2>Meet With Our Expert Team</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { name: 'John Doe', role: 'CEO & Founder', img: 'team-img1.png' },
                            { name: 'Jane Smith', role: 'Digital Marketing Officer', img: 'team-img2.png' },
                            { name: 'Sarah Thompson', role: 'Web Designer', img: 'team-img3.png' },
                            { name: 'David Garcia', role: 'Content Writer', img: 'team-img4.png' }
                        ].map((member, i) => (
                            <div className="col-lg-3 col-md-6" key={i}>
                                <div className={`team-boxarea${i === 3 ? ' m-0' : ''}`}>
                                    <div className="img1"><img src={`/assets/img/all-images/${member.img}`} alt="" /></div>
                                    <ul>
                                        <li><Link to="#"><img src="/assets/img/icons/facebook.svg" alt="" /></Link></li>
                                        <li><Link to="#"><img src="/assets/img/icons/instagram.svg" alt="" /></Link></li>
                                        <li><Link to="#"><img src="/assets/img/icons/linkedin.svg" alt="" /></Link></li>
                                        <li><Link to="#" className="m-0"><img src="/assets/img/icons/youtube.svg" alt="" /></Link></li>
                                    </ul>
                                    <div className="content">
                                        <Link to="/team">{member.name}</Link>
                                        <p>{member.role}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* BLOG AREA STARTS */}
            <div className="blog1-scetion-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="blog-hedaer-area heading2 text-center">
                                <h5>Blog</h5>
                                <h2>Our Latest Blog & News</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { title: "10 Essential SEO Tips to Boost Your Website's Ranking", img: 'blog-img1.png' },
                            { title: "The Power of PPC Advertising: How to Maximize Your ROI", img: 'blog-img2.png' },
                            { title: "The Importance of Responsive Web Design in the Mobile Age", img: 'blog-img3.png' }
                        ].map((post, i) => (
                            <div className="col-lg-4 col-md-6" key={i}>
                                <div className="blog-author-boxarea">
                                    <div className="img1"><img src={`/assets/img/all-images/${post.img}`} alt="" /></div>
                                    <div className="content-area">
                                        <div className="tags-area">
                                            <ul>
                                                <li><Link to="#"><img src="/assets/img/icons/contact1.svg" alt="" />Ben Stokes</Link></li>
                                                <li><Link to="#"><img src="/assets/img/icons/calender1.svg" alt="" />16 August 2023</Link></li>
                                            </ul>
                                        </div>
                                        <Link to="/blog/1">{post.title}</Link>
                                        <p>Are you looking to improve your website's visibility and attract more organic traffic? </p>
                                        <Link to="/blog/1" className="readmore">Read More <i className="fa-solid fa-arrow-right"></i></Link>
                                    </div>
                                </div>
                                {i < 2 && <div className="space30 d-lg-none d-block"></div>}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* CTA SECTION */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
