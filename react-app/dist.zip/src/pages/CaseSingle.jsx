import { Link } from 'react-router-dom'

export default function CaseSingle() {
    return (
        <>
            {/* PAGE HEADER */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Keyword Research & Analysis</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> Case <i className="fa-solid fa-angle-right"></i> <span>Keyword Research & Analysis</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* AUTHOR / INFORMATION SECTION */}
            <div className="case-single-section-area">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="case-auhtor-area sp1">
                                <div className="row align-items-center">
                                    <div className="col-lg-4">
                                        <div className="case-single-hedaer heading2">
                                            <h2>Information</h2>
                                            <p>Keyword research is a crucial step in any successful SEO strategy. It involves identifying and analyzing the search terms that your target audience uses when looking for products, services, or information related to your.</p>
                                            <div className="case-others-area">
                                                <ul>
                                                    <li><span>Category:</span>Keyword Research & Analysis</li>
                                                    <li><span>Date:</span>12 May, 2024</li>
                                                    <li><span>Client:</span>John Smith</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-1"></div>
                                    <div className="col-lg-7">
                                        <div className="case-images image-anime">
                                            <img src="/assets/img/all-images/case-img18.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* PROJECT BRIEF SECTION */}
            <div className="case-lista-area sp1 bg2">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-7">
                            <div className="case-pera-area heading2">
                                <h2>Project Brief:</h2>
                                <p>Before embarking on any SEO strategy, it's crucial to conduct thorough keyword research and analysis. This process begins by understanding your target audience their needs preferences, and pain points. From there, you can brainstorm seed keywords that describe your business, products, and services. Leveraging keyword research tools like Google Keyword Planner or SEMrush, you can expand your keyword list by uncovering variations, synonyms, and long-tail keywords relevant to your industry. Evaluating keyword metrics such as search volume, competition, and relevance helps prioritize which keywords to target. Equally important is considering the search intent behind each keyword—whether users are seeking information, products, or services. Organizing keywords into categories based on relevance and search intent streamlines content creation efforts. By continuously monitoring keyword performance and refining your strategy based on changes in search trends and business goals, you can ensure that your SEO efforts remain effective competitive ever-evolving digital landscape.</p>
                                <div className="space20"></div>
                                <p>Effective SEO begins with a solid foundation of keyword research and analysis. Understanding your target audience is paramount, as it enables you to identify their needs, preferences, and pain points. By creating detailed buyer personas, you can gain valuable insights into the demographics, behaviors, and motivations of your ideal customers. Armed with this knowledge, you can then begin brainstorming seed keywords—broad terms that encapsulate the essence of your business, products, and services. From there, you can leverage a variety of keyword research tools, such as Google Keyword Planner, SEMrush, or Ahrefs, to expand your keyword list. These tools provide valuable insights into search volume, competition, and related keywords, helping you uncover hidden opportunities and niche markets. As you compile your list of potential keywords, it's important to evaluate each one based on its relevance, search volume, and competitiveness.</p>
                            </div>
                        </div>
                        <div className="col-lg-5">
                            <div className="case-list">
                                <ul>
                                    {[
                                        'Consider Search Intent',
                                        'Understand Your Audience',
                                        'Brainstorm Seed Keywords',
                                        'Expand Your Keyword List',
                                        'Evaluate Keyword Metrics',
                                        'Prioritize Your Keyword List Based',
                                        'Before Diving Into Keyword Research',
                                        'Organize Your Keyword List  Category',
                                        'Keyword Research is an Ongoing Process',
                                        'Start Brainstorming a List of Seed Keywords',
                                        'Analyze Keyword Metrics Such as Search Volume',
                                        'Keyword Research Tools Like Google Keyword Planner'
                                    ].map((text, i) => (
                                        <li key={i}><img src="/assets/img/icons/check6.svg" alt="" />{text}</li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* STEP-BY-STEP SECTIONS */}
            <div className="works-inner-section-area sp1">
                <div className="container">
                    {/* STEP 01 */}
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="about-all-images-area">
                                <img src="/assets/img/elements/elements14.png" alt="" className="elements12 keyframe5" />
                                <img src="/assets/img/elements/elements15.png" alt="" className="elements13 keyframe5" />
                                <div className="row">
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img1">
                                            <div className="space100"></div>
                                            <img src="/assets/img/all-images/about-img6.png" alt="" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img2">
                                            <img src="/assets/img/all-images/service-img5.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="works-header-area heading2 specing2">
                                <h5>Step 01</h5>
                                <h2>Understand Your Audience</h2>
                                <p>Before diving into keyword research, it's essential to understand your target audience and their needs. Consider creating a buyer persona to outline key demographic information, pain points, preferences of your ideal customers.</p>
                                <div className="space32"></div>
                                <div className="btn-area1">
                                    <Link to="/case" className="header-btn1">Our Case Study <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="space100 d-lg-block d-none"></div>
                    <div className="space30 d-lg-none d-block"></div>

                    {/* STEP 02 */}
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="works-header-area heading2">
                                <h5>Step 02</h5>
                                <h2>Expand Your Keyword List</h2>
                                <p>Use keyword research tools like Google Keyword Planner, SEMrush, or Ahrefs to expand your list of potential keywords. Enter your seed keywords into the tool and explore the suggested keyword ideas. Look for variations, synonyms, long-tail keywords, & related terms that your audience may be searching for.</p>
                                <div className="space32"></div>
                                <div className="btn-area1">
                                    <Link to="/case" className="header-btn1">Our Case Study <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="about-all-images-area">
                                <img src="/assets/img/elements/elements14.png" alt="" className="elements12 keyframe5" />
                                <img src="/assets/img/elements/elements15.png" alt="" className="elements13 keyframe5" />
                                <div className="row">
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img1">
                                            <div className="space100"></div>
                                            <img src="/assets/img/all-images/service-img6.png" alt="" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img2">
                                            <img src="/assets/img/all-images/service-img7.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="space100 d-lg-block d-none"></div>
                    <div className="space30 d-lg-none d-block"></div>

                    {/* STEP 03 */}
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="about-all-images-area">
                                <img src="/assets/img/elements/elements14.png" alt="" className="elements12 keyframe5" />
                                <img src="/assets/img/elements/elements15.png" alt="" className="elements13 keyframe5" />
                                <div className="row">
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img1">
                                            <div className="space100"></div>
                                            <img src="/assets/img/all-images/service-img8.png" alt="" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6">
                                        <div className="img2">
                                            <img src="/assets/img/all-images/service-img9.png" alt="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="works-header-area heading2 specing2">
                                <h5>Step 03</h5>
                                <h2>Evaluate Keyword Metrics</h2>
                                <p>Analyze keyword metrics such as search volume, competition, and relevance to determine which keywords are worth targeting. Focus on keywords with high search volume, low competition, and high relevance to your business. Pay attention to metrics like average monthly searches, keyword difficulty, and cost-per-click (CPC) if you're planning to use paid advertising.</p>
                                <div className="space32"></div>
                                <div className="btn-area1">
                                    <Link to="/case" className="header-btn1">Our Case Study <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CTA SECTION */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
