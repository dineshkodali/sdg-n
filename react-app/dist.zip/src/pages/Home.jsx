import { Link } from 'react-router-dom'
import { useEffect } from 'react'

export default function Home() {
    useEffect(() => {
        // Re-init owl carousel for testimonials slider after render
        if (window.$ && window.$.fn.owlCarousel) {
            window.$('.testimonial13-slider.owl-carousel').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                dots: true,
                autoplay: true,
                responsive: {
                    0: { items: 1 },
                    768: { items: 2 },
                    1200: { items: 2 }
                }
            })
        }
    }, [])

    return (
        <div className="homepage13-body">

            {/* HERO AREA */}
            <div className="hero13-section-area">
                <div className="img2">
                    <img src="/assets/img/bg/header-bg13.png" alt="" className="header-bg13" />
                </div>
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="hero13-header heading19">
                                <h5><img src="/assets/img/icons/logo-icons8.svg" alt="" /> Top #1 SEO &amp; Advertising Agency</h5>
                                <div className="space16"></div>
                                <h2>We Build Campaigns That Make Brands Unforgettable</h2>
                                <div className="space24"></div>
                                <p>At our agency, we believe that creativity has the power to transform brands and connect them with their audiences in meaningful ways.</p>
                                <div className="space32"></div>
                                <div className="btn-area1">
                                    <Link to="/case" className="header-btn21">Our Success Stories <i className="fa-solid fa-arrow-right"></i></Link>
                                    <Link to="/contact" className="header-btn21 btn2">Contact <i className="fa-solid fa-arrow-right"></i></Link>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-1"></div>
                        <div className="col-lg-5">
                            <div className="img1">
                                <img src="/assets/img/all-images/new-img/header-img13.png" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* ABOUT AREA */}
            <div className="about13-section-area sp1">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="images-area" data-aos="zoom-in" data-aos-duration="1000">
                                <div className="img1">
                                    <img src="/assets/img/all-images/new-img/about-img1-h13.png" alt="" />
                                </div>
                                <div className="img2">
                                    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 288 288">
                                        <linearGradient id="imagewave" x1="70.711%" x2="0%" y1="70.711%" y2="0%">
                                            <stop className="stop-color2" offset="0%" stopOpacity="1"></stop>
                                            <stop className="stop-color1" offset="100%" stopOpacity="1"></stop>
                                        </linearGradient>
                                        <path fill="url(#imagewave)">
                                            <animate repeatCount="indefinite" attributeName="d" dur="5s"
                                                values="M37.5,186c-12.1-10.5-11.8-32.3-7.2-46.7c4.8-15,13.1-17.8,30.1-36.7C91,68.8,83.5,56.7,103.4,45 c22.2-13.1,51.1-9.5,69.6-1.6c18.1,7.8,15.7,15.3,43.3,33.2c28.8,18.8,37.2,14.3,46.7,27.9c15.6,22.3,6.4,53.3,4.4,60.2 c-3.3,11.2-7.1,23.9-18.5,32c-16.3,11.5-29.5,0.7-48.6,11c-16.2,8.7-12.6,19.7-28.2,33.2c-22.7,19.7-63.8,25.7-79.9,9.7 c-15.2-15.1,0.3-41.7-16.6-54.9C63,186,49.7,196.7,37.5,186z;M51,171.3c-6.1-17.7-15.3-17.2-20.7-32c-8-21.9,0.7-54.6,20.7-67.1c19.5-12.3,32.8,5.5,67.7-3.4C145.2,62,145,49.9,173,43.4 c12-2.8,41.4-9.6,60.2,6.6c19,16.4,16.7,47.5,16,57.7c-1.7,22.8-10.3,25.5-9.4,46.4c1,22.5,11.2,25.8,9.1,42.6 c-2.2,17.6-16.3,37.5-33.5,40.8c-22,4.1-29.4-22.4-54.9-22.6c-31-0.2-40.8,39-68.3,35.7c-17.3-2-32.2-19.8-37.3-34.8 C48.9,198.6,57.8,191,51,171.3z;M37.5,186c-12.1-10.5-11.8-32.3-7.2-46.7c4.8-15,13.1-17.8,30.1-36.7C91,68.8,83.5,56.7,103.4,45 c22.2-13.1,51.1-9.5,69.6-1.6c18.1,7.8,15.7,15.3,43.3,33.2c28.8,18.8,37.2,14.3,46.7,27.9c15.6,22.3,6.4,53.3,4.4,60.2 c-3.3,11.2-7.1,23.9-18.5,32c-16.3,11.5-29.5,0.7-48.6,11c-16.2,8.7-12.6,19.7-28.2,33.2c-22.7,19.7-63.8,25.7-79.9,9.7 c-15.2-15.1,0.3-41.7-16.6-54.9C63,186,49.7,196.7,37.5,186z"
                                            ></animate>
                                        </path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="about13-header heading20">
                                <h5 data-aos="fade-left" data-aos-duration="800"><img src="/assets/img/icons/logo-icons8.svg" alt="" />About</h5>
                                <div className="space16"></div>
                                <h2 className="text-anime-style-3">The Minds Behind Your Brand's Success</h2>
                                <div className="space16"></div>
                                <p data-aos="fade-left" data-aos-duration="1000">At the heart of our agency is a passion for creativity and a relentless drive to push boundaries. We are a team of thinkers, dreamers, and doers who specialize in crafting unique strategies bring brands.</p>
                                <div className="row">
                                    <div className="col-lg-6 col-md-6" data-aos="zoom-in" data-aos-duration="900">
                                        <div className="about-icons">
                                            <div className="icons"><img src="/assets/img/icons/about1-h13.svg" alt="" /></div>
                                            <Link to="/about">Our Story Creative Innovation</Link>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6" data-aos="zoom-in" data-aos-duration="1000">
                                        <div className="about-icons">
                                            <div className="icons"><img src="/assets/img/icons/about2-h13.svg" alt="" /></div>
                                            <Link to="/about">Driven Creativity Focused</Link>
                                        </div>
                                    </div>
                                </div>
                                <div className="space24"></div>
                                <p data-aos="fade-left" data-aos-duration="1100">Our mission is simple: to help brands stand in a crowded market &amp; connect with their audience in meaningful, lasting ways. We're not just an agency.</p>
                                <div className="space32"></div>
                                <div className="btn-area1" data-aos="fade-left" data-aos-duration="1200">
                                    <Link to="/contact" className="header-btn21">Get Free Quote <i className="fa-solid fa-arrow-right"></i></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* SERVICE AREA */}
            <div className="service13-section-area sp2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="header-area-service space-margin60">
                                <div className="heading20">
                                    <h5><img src="/assets/img/icons/logo-icons8.svg" alt="" />Our Services</h5>
                                    <div className="space16"></div>
                                    <h2 className="text-anime-style-3">Tailored Solutions For <br className="d-md-block d-none" />Every Brand</h2>
                                </div>
                                <div className="btn-area1">
                                    <Link to="/services" className="header-btn21">View All Service <i className="fa-solid fa-arrow-right"></i></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { icon: 'service-icons23.svg', title: 'Advertising Campaign Creation', num: '01' },
                            { icon: 'service-icons24.svg', title: 'Brand Strategy & Development', num: '02' },
                            { icon: 'service-icons25.svg', title: 'Targeted Media Buying & Planning', num: '03' },
                            { icon: 'service-icons26.svg', title: 'Graphic Design & Visual Branding', num: '04' },
                            { icon: 'service-icons27.svg', title: 'Influencer Marketing Partnerships', num: '05' },
                            { icon: 'service-icons28.svg', title: 'Video Production & Animation', num: '06' },
                        ].map((s, i) => (
                            <div className="col-lg-4 col-md-6" key={i} data-aos="zoom-in" data-aos-duration={800 + i * 100}>
                                <div className="service13-boxarea">
                                    <div className="icons"><img src={`/assets/img/icons/${s.icon}`} alt="" /></div>
                                    <div className="space32"></div>
                                    <div className="content-area">
                                        <Link to="/services" className="head">{s.title}</Link>
                                        <div className="space16"></div>
                                        <p>Our agency offers a comprehensive range of services designed to elevate your brand and maximize its impact.</p>
                                        <div className="space24"></div>
                                        <Link to="/services" className="readmore">Learn More <i className="fa-solid fa-arrow-right"></i></Link>
                                        <h2>{s.num}</h2>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* WORK / PORTFOLIO AREA */}
            <div className="work13-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-5 m-auto">
                            <div className="work-haader text-center heading20 space-margin60">
                                <h5 data-aos="fade-left" data-aos-duration="800"><img src="/assets/img/icons/logo-icons8.svg" alt="" />Projects</h5>
                                <div className="space16"></div>
                                <h2 className="text-anime-style-3">The Work That Drives Brands Forward</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { img: 'service-img1-h13.png', col: 'col-lg-5' },
                            { img: 'service-img2-h13.png', col: 'col-lg-3' },
                            { img: 'service-img3-h13.png', col: 'col-lg-4' },
                            { img: 'service-img4-h13.png', col: 'col-lg-3' },
                            { img: 'service-img5-h13.png', col: 'col-lg-5' },
                            { img: 'service-img6-h13.png', col: 'col-lg-4' },
                        ].map((p, i) => (
                            <div className={`${p.col} col-md-6`} key={i} data-aos="zoom-in" data-aos-duration={700 + i * 100}>
                                <div className="project13-boxrea">
                                    <div className="img1 image-anime">
                                        <img src={`/assets/img/all-images/new-img/${p.img}`} alt="" />
                                    </div>
                                    <div className="content-area">
                                        <span>#Advertising Agency</span>
                                        <div className="space16"></div>
                                        <Link to="/case-study">A branding &amp; visual <br />design overhaul.</Link>
                                    </div>
                                </div>
                            </div>
                        ))}
                        <div className="col-lg-12">
                            <div className="btn-area1 text-center">
                                <Link to="/case" className="header-btn21">View All Projects <i className="fa-solid fa-arrow-right"></i></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* TESTIMONIALS */}
            <div className="testimonial13-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-5">
                            <div className="testimonial13-header heading20 space-margin60">
                                <h5 data-aos="fade-left" data-aos-duration="800"><img src="/assets/img/icons/logo-icons8.svg" alt="" />Testimonials</h5>
                                <div className="space16"></div>
                                <h2 className="text-anime-style-3">Success Stories from <br className="d-md-block d-none" />Our Partners</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="testimonial13-slider owl-carousel">
                                {[
                                    { name: 'Arturo Reynolds', role: 'Company Owner', img: 'testimonial-img1-h13.png', text: '"Our clients\' success is our greatest achievement. We pride ourselves on building strong, collaborative relationships that drive exceptional results."' },
                                    { name: 'Stewart Parisian', role: 'Company Owner', img: 'testimonial-img2-h13.png', text: '"Our clients consistently commend us for our ability to turn ambitious ideas into successful campaigns."' },
                                    { name: 'Emily Johnson', role: 'Marketing Director', img: 'testimonial-img1-h13.png', text: '"Working with this agency transformed our brand presence. Their creativity and strategic approach are unmatched in the industry."' },
                                ].map((t, i) => (
                                    <div className="testimonial13-boxrea" key={i}>
                                        <ul>
                                            {[...Array(5)].map((_, j) => <li key={j}><i className="fa-solid fa-star"></i></li>)}
                                        </ul>
                                        <div className="space24"></div>
                                        <p>{t.text}</p>
                                        <div className="space24"></div>
                                        <div className="name-area">
                                            <div className="name-text">
                                                <img src={`/assets/img/all-images/new-img/${t.img}`} alt="" />
                                                <div className="content">
                                                    <a href="#">{t.name}</a>
                                                    <div className="space12"></div>
                                                    <p>{t.role}</p>
                                                </div>
                                            </div>
                                            <img src="/assets/img/icons/quito8.svg" alt="" className="quito8" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* TEAM */}
            <div className="team13-section-area sp2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="team13-header text-center heading20 space-margin60">
                                <h5><img src="/assets/img/icons/logo-icons8.svg" alt="" />Team</h5>
                                <div className="space16"></div>
                                <h2 className="text-anime-style-3">Our Team: Where Creativity Meets Strategy</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { name: 'Krystal Hermann', role: 'CEO & Founder', img: 'team-img1-h13.png' },
                            { name: 'Arnold Beier V', role: 'CEO & Founder', img: 'team-img2-h13.png' },
                            { name: 'Lucas Hagenes', role: 'CEO & Founder', img: 'team-img3-h13.png' },
                        ].map((m, i) => (
                            <div className="col-lg-4 col-md-6" key={i} data-aos="zoom-in" data-aos-duration={800 + i * 200}>
                                <div className="team13-boxarea">
                                    <div className="img1 image-anime">
                                        <img src={`/assets/img/all-images/new-img/${m.img}`} alt="" />
                                    </div>
                                    <div className="space24"></div>
                                    <div className="content-area">
                                        <Link to="/team">{m.name}</Link>
                                        <div className="space12"></div>
                                        <p>{m.role}</p>
                                    </div>
                                    <ul>
                                        <li><a href="#"><i className="fa-brands fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i className="fa-brands fa-instagram"></i></a></li>
                                        <li><a href="#"><i className="fa-brands fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i className="fa-brands fa-youtube"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* INTEGRATIONS / OTHERS */}
            <div className="others13-section-area sp1">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-5">
                            <div className="others-header heading20">
                                <h2 className="text-anime-style-3">All Your Client's Marketing Data in One Place</h2>
                                <div className="space16"></div>
                                <p data-aos="fade-left" data-aos-duration="1000">Marketing moves fast, and so do we. With 75+ marketing integration and new releases each month, we'll keep you up-to-date with all your client's data in one place.</p>
                                <div className="space32"></div>
                                <div className="btn-area1" data-aos="fade-left" data-aos-duration="1200">
                                    <Link to="/contact" className="header-btn21">Get A Free Proposal <i className="fa-solid fa-arrow-right"></i></Link>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-1"></div>
                        <div className="col-lg-6">
                            <div className="row">
                                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n, i) => (
                                    <div className="col-lg-4 col-md-6" key={i} data-aos="zoom-in" data-aos-duration={800 + i * 100}>
                                        <div className="img1">
                                            <img src={`/assets/img/all-images/new-img/others-img${n}-h13.png`} alt="" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* BLOG */}
            <div className="blog13-section-area sp2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-5 m-auto">
                            <div className="blog4-header text-center heading20 space-margin60">
                                <h5 data-aos="fade-up" data-aos-duration="1000"><img src="/assets/img/icons/logo-icons8.svg" alt="" />Blog &amp; News</h5>
                                <div className="space16"></div>
                                <h2 className="text-anime-style-3">Agency Insights: Trends, Tips &amp; More</h2>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        {[
                            { img: 'blog-img1-h13.png', title: 'Unleashing Creativity: The Art and Science of Effective Advertising' },
                            { img: 'blog-img2-h13.png', title: 'Exploring Strategies, Trends, and Insights to Elevate Your Brand' },
                            { img: 'blog-img3-h13.png', title: 'Unleashing Creativity: Trends Shaping the Future of Advertising' },
                        ].map((b, i) => (
                            <div className="col-lg-4 col-md-6" key={i} data-aos="zoom-out" data-aos-duration={800 + i * 200}>
                                <div className="blog-auhtor-boxarea">
                                    <ul>
                                        <li><a href="#"><i className="fa-regular fa-circle-user"></i>John Doe</a></li>
                                        <li className="m-0"><a href="#"><i className="fa-solid fa-calendar-days"></i> 12 Feb 2024</a></li>
                                    </ul>
                                    <div className="space24"></div>
                                    <div className="img1 image-anime">
                                        <img src={`/assets/img/all-images/new-img/${b.img}`} alt="" />
                                    </div>
                                    <div className="space24"></div>
                                    <div className="blog-content-area">
                                        <Link to="/blog/1">{b.title}</Link>
                                        <div className="space16"></div>
                                        <p>Explore how emerging trends and innovative strategies are revolutionizing the advertising landscape.</p>
                                        <div className="space24"></div>
                                        <Link to="/blog/1" className="readmore">Learn More<i className="fa-solid fa-arrow-right"></i></Link>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* CTA BANNER */}
            <div className="cta13-section-area sp1">
                <img src="/assets/img/bg/cta13-bg1.png" alt="" className="cta13-bg1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="cta13-header text-center heading20">
                                <h2 className="text-anime-style-3">Take Your Brand To The Next Level!<br className="d-lg-block d-none" />To Begin Your Success Story.</h2>
                                <div className="space16"></div>
                                <p data-aos="fade-up" data-aos-duration="1000">Ready to elevate your brand and achieve exceptional results? Our team of creative experts is here to turn your vision into reality.</p>
                                <div className="space40"></div>
                                <div className="btn-area1" data-aos="fade-up" data-aos-duration="1200">
                                    <Link to="/contact" className="header-btn21">Get Started Today <i className="fa-solid fa-arrow-right"></i></Link>
                                    <Link to="/contact" className="header-btn21 btn2">Request a Consultation <i className="fa-solid fa-arrow-right"></i></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
