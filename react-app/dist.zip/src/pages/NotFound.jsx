import { Link } from 'react-router-dom'

export default function NotFound() {
    return (
        <>
            {/* HERO AREA STARTS */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <img src="/assets/img/elements/elements1.png" alt="" className="elements1 aniamtion-key-1" />
                <img src="/assets/img/elements/star2.png" alt="" className="star2 keyframe5" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>404 Error</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>404 Error</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* HERO AREA ENDS */}

            {/* ERROR AREA STARTS */}
            <div className="error-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="heading2 text-center">
                                <img src="/assets/img/all-images/error-img1.png" alt="" />
                                <div className="space50"></div>
                                <h2> Sorry! Page Not Found!</h2>
                                <div className="space16"></div>
                                <p>Sorry, the page you are looking for doesn’t exist or has <br className="d-lg-block d-none" /> been moved. Here are some helpful links.</p>
                                <div className="space24"></div>
                                <div className="btn-area1">
                                    <Link to="/" className="header-btn1">Back To Home <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* ERROR AREA ENDS */}

            {/* CTA AREA STARTS */}
            <div className="cta-section-area">
                <img src="/assets/img/bg/cta-bg1.png" alt="" className="cta-bg1 aniamtion-key-2" />
                <img src="/assets/img/bg/cta-bg2.png" alt="" className="cta-bg2 aniamtion-key-1" />
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12 m-auto">
                            <div className="cta-header-area text-center sp4 heading2">
                                <h2>Ready To Take Your SEO To <br className="d-md-block d-none" /> The Next Level</h2>
                                <p>Effective SEO strategies not only elevate a website's visibility but also drive <br className="d-md-block d-none" /> targeted traffic, enhance user experience,</p>
                                <div className="btn-area text-center">
                                    <Link to="/contact" className="header-btn1">Free Consultation <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* CTA AREA ENDS */}
        </>
    )
}
