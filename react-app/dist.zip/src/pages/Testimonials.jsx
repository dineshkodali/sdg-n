import { Link } from 'react-router-dom'

const testimonials = [
    { name: 'Arturo Reynolds', role: 'Company Owner', img: 'testimonial-img1.png', text: '"Our clients\' success is our greatest achievement. We pride ourselves on building strong, collaborative relationships that drive exceptional results."' },
    { name: 'Stewart Parisian', role: 'Company Owner', img: 'testimonial-img2.png', text: '"Our clients consistently commend us for our ability to turn ambitious ideas into successful campaigns that deliver real, measurable results."' },
    { name: 'Emily Johnson', role: 'Marketing Director', img: 'testimonial-img1.png', text: '"Working with SDG Solutions transformed our brand presence. Their creativity and strategic approach are unmatched in the industry."' },
    { name: 'Michael Adams', role: 'CEO', img: 'testimonial-img2.png', text: '"The team at SDG Solutions helped us achieve a 200% increase in organic traffic. Highly recommend their SEO services."' },
    { name: 'Sarah Williams', role: 'Brand Manager', img: 'testimonial-img1.png', text: '"Exceptional results and professional service. They really understand digital marketing and know how to deliver for their clients."' },
    { name: 'James Cooper', role: 'Founder', img: 'testimonial-img2.png', text: '"From start to finish, the team was professional, responsive, and incredibly skilled. Our ROI has never been better."' },
]

export default function Testimonials() {
    return (
        <>
            {/* PAGE HEADER */}
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Testimonials</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>Testimonials</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* BRAND SLIDER SECTION */}
            <div className="slider-section-area slider-inner sp5">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-2">
                            <div className="sldier-head">
                                <p>Trusted by <br className="d-lg-block d-none" /> Top Companies</p>
                            </div>
                        </div>
                        <div className="col-lg-10">
                            <div className="slider-images-area owl-carousel">
                                {[1, 2, 3, 4, 5].map(n => (
                                    <div className="img1" key={n}>
                                        <img src={`/assets/img/elements/brand-img${n}.png`} alt={`Brand ${n}`} />
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* FEATURED TESTIMONIAL HERO */}
            <div className="testimonial-hero-section sp6 bg2">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6" data-aos="fade-right" data-aos-duration="1000">
                            <div className="testimonial-hero-img position-relative">
                                <img src="/assets/img/all-images/about-img1.png" alt="Happy Client" className="img-fluid rounded-4 shadow-lg" />
                                <div className="experience-tag position-absolute bottom-0 start-0 p-4 bg-primary rounded-end-4 text-white shadow">
                                    <h2 className="m-0 text-white">10+</h2>
                                    <p className="m-0 text-white font-weight-bold uppercase">Years Experience</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6" data-aos="fade-left" data-aos-duration="1000">
                            <div className="testimonial-hero-content heading2 ms-lg-4 mt-4 mt-lg-0">
                                <h5>Featured Success Story</h5>
                                <h2>"SDG Solutions didn't just provide a service; they became an extension of our team."</h2>
                                <p className="lead">Through targeted SEO and innovative digital strategies, SDG Solutions helped us scale our organic reach by 300% in under six months. Their attention to detail and data-driven approach is unmatched.</p>
                                <div className="space24"></div>
                                <div className="author-detail">
                                    <h4 className="mb-1">Arturo Reynolds</h4>
                                    <p className="m-0 text-secondary">CEO & Founder, Global Logistics</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* SUCCESS METRICS (COUNTERS) */}
            <div className="counter-section-area sp6 bg-white">
                <div className="container">
                    <div className="row">
                        {[
                            { count: '100+', label: 'Projects Completed', icon: 'works-icons7.svg' },
                            { count: '99%', label: 'Client Satisfaction', icon: 'works-icons8.svg' },
                            { count: '10M+', label: 'Traffic Generated', icon: 'works-icons9.svg' },
                            { count: '24/7', label: 'Dedicated Support', icon: 'works-icons10.svg' },
                        ].map((s, i) => (
                            <div className="col-lg-3 col-md-6 text-center mb-4 mb-lg-0" key={i} data-aos="fade-up" data-aos-duration={600 + i * 200}>
                                <div className="counter-box shadow-sm p-5 rounded-4 border bg-light h-100">
                                    <img src={`/assets/img/icons/${s.icon}`} alt="" style={{ width: '56px', height: '56px' }} />
                                    <div className="space24"></div>
                                    <h2 className="fw-bold text-dark">{s.count}</h2>
                                    <p className="m-0 text-muted font-weight-bold">{s.label}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* MAIN TESTIMONIAL GRID */}
            <div className="testimonial-inner-section-area sp1 bg2">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="testimonial-header text-center heading2">
                                <h5>Wall of Love</h5>
                                <h2>Trust Built on Proven Results</h2>
                            </div>
                        </div>
                    </div>
                    <div className="space50"></div>
                    <div className="row">
                        {testimonials.map((t, i) => (
                            <div className="col-lg-4 col-md-6 mb-4" key={i} data-aos="zoom-in" data-aos-duration={800 + (i % 3) * 200}>
                                <div className="testimonial-boxarea h-100 shadow-sm border-0 p-4 bg-white rounded-4">
                                    <ul className="d-flex list-unstyled mb-3">
                                        {[...Array(5)].map((_, j) => <li key={j} className="text-warning"><i className="fa-solid fa-star"></i></li>)}
                                    </ul>
                                    <div className="space16"></div>
                                    <p className="fst-italic text-muted">{t.text}</p>
                                    <div className="space24"></div>
                                    <div className="author-area border-top pt-3 d-flex align-items-center">
                                        <img src={`/assets/img/all-images/${t.img}`} alt={t.name} className="rounded-circle shadow-sm" style={{ width: '50px', height: '50px', objectFit: 'cover' }} />
                                        <div className="content ms-3">
                                            <h6 className="m-0 fw-bold">{t.name}</h6>
                                            <p className="m-0 small text-secondary">{t.role}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* VIDEO PROOF SECTION */}
            <div className="video-testimonial-section sp6 bg-white">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-10 m-auto text-center heading2">
                            <h5>Video Success Stories</h5>
                            <h2>Hear directly from our partners</h2>
                            <p>Real stories, real people, real success. Watch how we've helped businesses like yours dominate the digital space.</p>
                        </div>
                    </div>
                    <div className="space40"></div>
                    <div className="row justify-content-center">
                        <div className="col-lg-12">
                            <div className="video-thumb position-relative shadow-lg rounded-4 overflow-hidden" data-aos="zoom-in">
                                <img src="/assets/img/all-images/case-img1.png" alt="Video Placeholder" className="w-100" style={{ height: '500px', objectFit: 'cover' }} />
                                <div className="video-overlay position-absolute top-50 start-50 translate-middle">
                                    <div className="play-btn-pulse">
                                        <a href="#" className="video-play-btn bg-white text-primary rounded-circle d-flex align-items-center justify-content-center shadow-lg" style={{ width: '80px', height: '80px' }} onClick={(e) => e.preventDefault()}>
                                            <i className="fa-solid fa-play fa-2x"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* FINAL CTA */}
            <div className="cta-section-area sp6 bg-dark text-white rounded-top-5">
                <div className="container text-center">
                    <div className="row">
                        <div className="col-lg-8 m-auto heading2">
                            <h2 className="text-white mb-3">Ready to become our next success story?</h2>
                            <p className="text-white-50 mb-4">Join hundreds of growing brands that trust SDG Solutions with their digital growth.</p>
                            <Link to="/contact" className="header-btn1">Get Started Today <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
