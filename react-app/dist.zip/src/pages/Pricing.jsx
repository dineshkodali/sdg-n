import { Link } from 'react-router-dom'

const plans = [
    {
        name: 'Starter',
        price: '$49',
        features: ['5 Keywords Optimization', '10 Pages', 'On-Page SEO', 'Monthly Reporting', 'Email Support'],
    },
    {
        name: 'Professional',
        price: '$99',
        features: ['20 Keywords Optimization', '25 Pages', 'On-Page & Off-Page SEO', 'Weekly Reporting', 'Priority Support', 'Social Media Management'],
        featured: true,
    },
    {
        name: 'Enterprise',
        price: '$199',
        features: ['Unlimited Keywords', 'Unlimited Pages', 'Full SEO Suite', 'Daily Reporting', '24/7 Dedicated Support', 'Full Digital Marketing'],
    },
]

export default function Pricing() {
    return (
        <>
            <div className="about-header-area" style={{ backgroundImage: 'url(/assets/img/bg/inner-header.png)', backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 m-auto">
                            <div className="about-inner-header heading9 text-center">
                                <h1>Pricing</h1>
                                <Link to="/">Home <i className="fa-solid fa-angle-right"></i> <span>Pricing</span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="pricing-section-area sp1">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 m-auto">
                            <div className="pricing-header text-center heading2">
                                <h5>Pricing</h5>
                                <h2>Simple, Transparent Pricing</h2>
                                <p>Choose the plan that fits your business needs. All plans include our core features.</p>
                            </div>
                        </div>
                    </div>
                    <div className="space50"></div>
                    <div className="row">
                        {plans.map((plan, i) => (
                            <div className="col-lg-4 col-md-6" key={i} data-aos="zoom-in" data-aos-duration={800 + i * 200}>
                                <div className={`pricing-boxarea${plan.featured ? ' active' : ''}`}>
                                    <div className="pricing-header-content">
                                        <h4>{plan.name}</h4>
                                        <div className="price">
                                            <h2>{plan.price}<span>/month</span></h2>
                                        </div>
                                    </div>
                                    <div className="space24"></div>
                                    <ul className="pricing-list">
                                        {plan.features.map((f, j) => (
                                            <li key={j}><i className="fa-solid fa-check"></i> {f}</li>
                                        ))}
                                    </ul>
                                    <div className="space32"></div>
                                    <Link to="/contact" className="header-btn1">Get Started <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    )
}
