import { Link } from 'react-router-dom'

export default function Footer() {
    return (
        <div className="footer13-section-area">
            <div className="container">
                <div className="row">
                    <div className="col-lg-3 col-md-6">
                        <div className="footer-logo-area">
                            <Link to="/"><img src="/assets/img/logo/sdg-logo.jpg" alt="SDG Solutions" style={{ marginBottom: '20px', maxHeight: '70px' }} /></Link>
                            <p>By optimizing content, leveraging relevant keywords, and adhering to best practices, businesses can secure prominent position (SEO)</p>
                            <ul>
                                <li><a href="#"><i className="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="#"><i className="fa-brands fa-instagram"></i></a></li>
                                <li><a href="#"><i className="fa-brands fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i className="fa-brands fa-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-2 col-md-6">
                        <div className="footer-logo-area1">
                            <h3>Our Services</h3>
                            <ul>
                                <li><Link to="/services">SEO Marketing</Link></li>
                                <li><Link to="/services">PPC Advertising</Link></li>
                                <li><Link to="/services">Social Marketing</Link></li>
                                <li><Link to="/services">Web Development</Link></li>
                                <li><Link to="/services">Digital Strategy</Link></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-2 col-md-6">
                        <div className="footer-logo-area1">
                            <h3>Company</h3>
                            <ul>
                                <li><Link to="/about">About</Link></li>
                                <li><Link to="/team">Team</Link></li>
                                <li><Link to="/pricing">Pricing</Link></li>
                                <li><Link to="/testimonials">Testimonials</Link></li>
                                <li><Link to="/contact">Contact</Link></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-2 col-md-6">
                        <div className="footer-logo-area1">
                            <h3>Resources</h3>
                            <ul>
                                <li><Link to="/blog">Blog</Link></li>
                                <li><Link to="/case">Case Studies</Link></li>
                                <li><Link to="/faq">Help & FAQ</Link></li>
                                <li><Link to="/blog">Insights</Link></li>
                                <li><Link to="/contact">Support</Link></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-3 col-md-6">
                        <div className="footer-logo-area3">
                            <h3>Subscribe Newsletter</h3>
                            <form action="#" onSubmit={(e) => e.preventDefault()}>
                                <input type="email" placeholder="Enter Your email" required />
                                <div className="space16"></div>
                                <button className="header-btn21" type="submit" style={{ width: '100%', justifyContent: 'center' }}>
                                    Subscribe <span><i className="fa-solid fa-arrow-right"></i></span>
                                </button>
                            </form>
                            <div className="space20"></div>
                            <div className="contact-info">
                                <a href="tel:+441234567890" style={{ color: 'var(--ztc-text-text-1)', fontSize: '16px', display: 'block', marginBottom: '8px' }}>
                                    <i className="fa-solid fa-phone" style={{ marginRight: '10px' }}></i> +44 123 456 7890
                                </a>
                                <a href="mailto:info@sdgsolutions.com" style={{ color: 'var(--ztc-text-text-1)', fontSize: '16px', display: 'block' }}>
                                    <i className="fa-solid fa-envelope" style={{ marginRight: '10px' }}></i> info@sdgsolutions.com
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space50 d-lg-block d-none"></div>
                <div className="space40 d-lg-none d-block"></div>

                <div className="row">
                    <div className="col-lg-12">
                        <div className="copyright-area">
                            <div className="pera">
                                <p>&#169; Copyright 2024 SDG Solutions. All rights reserved</p>
                            </div>
                            <ul>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#" className="m-0">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
