import { Link } from 'react-router-dom'

export default function Header() {
    return (
        <>
            {/* DESKTOP HEADER */}
            <header>
                <div className="header-area homepage13 header header-sticky d-none d-lg-block" id="header">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="header-elements">
                                    <div className="site-logo">
                                        <Link to="/"><img src="/assets/img/logo/sdg-logo.jpg" alt="SDG Solutions" style={{ maxHeight: '60px' }} /></Link>
                                    </div>
                                    <div className="main-menu">
                                        <ul>
                                            <li>
                                                <Link to="/">Home <i className="fa-solid fa-angle-down"></i></Link>
                                            </li>
                                            <li><Link to="/about">About</Link></li>
                                            <li>
                                                <a href="#">Services <i className="fa-solid fa-angle-down"></i></a>
                                                <ul className="dropdown-padding">
                                                    <li><Link to="/services">Our Services</Link></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#">Blogs <i className="fa-solid fa-angle-down"></i></a>
                                                <ul className="dropdown-padding">
                                                    <li><Link to="/blog">Blog</Link></li>
                                                    <li><Link to="/blog/1">Blog Single</Link></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#">Pages <i className="fa-solid fa-angle-down"></i></a>
                                                <ul className="dropdown-padding">
                                                    <li><Link to="/case">Case</Link></li>
                                                    <li><Link to="/case/1">Case Single</Link></li>
                                                    <li><Link to="/team">Team</Link></li>
                                                    <li><Link to="/pricing">Pricing</Link></li>
                                                    <li><Link to="/testimonials">Testimonials</Link></li>
                                                    <li><Link to="/faq">FAQ</Link></li>
                                                </ul>
                                            </li>
                                            <li><Link to="/contact">Contact</Link></li>
                                        </ul>
                                    </div>
                                    <div className="btn-area">
                                        <Link to="/contact" className="header-btn21">Get Free Quote <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            {/* MOBILE HEADER */}
            <div className="mobile-header mobile-haeder13 d-block d-lg-none">
                <div className="container-fluid">
                    <div className="col-12">
                        <div className="mobile-header-elements">
                            <div className="mobile-logo">
                                <Link to="/"><img src="/assets/img/logo/sdg-logo.jpg" alt="SDG Solutions" style={{ maxHeight: '40px' }} /></Link>
                            </div>
                            <div className="mobile-nav-icon dots-menu">
                                <i className="fa-solid fa-bars"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="mobile-sidebar mobile-sidebar13">
                <div className="logosicon-area">
                    <div className="logos">
                        <img src="/assets/img/logo/sdg-logo.jpg" alt="" style={{ maxHeight: '50px' }} />
                    </div>
                    <div className="menu-close">
                        <i className="fa-solid fa-xmark"></i>
                    </div>
                </div>
                <div className="mobile-nav mobile-nav1">
                    <ul className="mobile-nav-list nav-list1">
                        <li><Link to="/">Home</Link></li>
                        <li><Link to="/about">About</Link></li>
                        <li>
                            <a href="#">Services</a>
                            <ul className="sub-menu">
                                <li><Link to="/services">Our Services</Link></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Blogs</a>
                            <ul className="sub-menu">
                                <li><Link to="/blog">Blog</Link></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Pages</a>
                            <ul className="sub-menu">
                                <li><Link to="/case">Case</Link></li>
                                <li><Link to="/team">Team</Link></li>
                                <li><Link to="/pricing">Pricing</Link></li>
                                <li><Link to="/testimonials">Testimonials</Link></li>
                                <li><Link to="/faq">FAQ</Link></li>
                            </ul>
                        </li>
                        <li><Link to="/contact">Contact</Link></li>
                    </ul>
                    <div className="allmobilesection">
                        <Link to="/contact" className="header-btn21">Get Started <span><i className="fa-solid fa-arrow-right"></i></span></Link>
                        <div className="single-footer">
                            <h3>Contact Info</h3>
                            <div className="footer1-contact-info">
                                <div className="contact-info-single">
                                    <div className="contact-info-icon"><i className="fa-solid fa-phone-volume"></i></div>
                                    <div className="contact-info-text"><a href="tel:+441234567890">+44 123 456 7890</a></div>
                                </div>
                                <div className="contact-info-single">
                                    <div className="contact-info-icon"><i className="fa-solid fa-envelope"></i></div>
                                    <div className="contact-info-text"><a href="mailto:info@sdgsolutions.com">info@sdgsolutions.com</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
